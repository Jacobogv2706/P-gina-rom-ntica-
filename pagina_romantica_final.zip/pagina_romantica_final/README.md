# Página romántica ❤️

Esta carpeta contiene la página completa con las fotos suministradas.

## Publicarla gratis
1. Crea un repositorio en GitHub.
2. Sube `index.html`, `style.css` y la carpeta `fotos`.
3. Ve a **Settings → Pages**.
4. Selecciona **Deploy from a branch**, rama `main` y carpeta `/root`.
5. GitHub generará una URL pública.
6. Esa URL será la que debe llevar el código QR.

## Personalizar
El mensaje está en `index.html`. Puedes cambiar nombres, fechas y cualquier frase antes de publicar.

## QR
El QR definitivo se genera después de tener la URL pública, para que al escanearlo abra directamente esta página.
